import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import "../../ExternalRef/css/bootstrap.css";
import "../../ExternalRef/css/style.css";
import "../../ExternalRef/js/bootstrap.js";
import "../../ExternalRef/css/alertify.min.css";
export interface IFlxLearningWebPartProps {
    description: string;
}
export default class FlxLearningWebPart extends BaseClientSideWebPart<IFlxLearningWebPartProps> {
    protected onInit(): Promise<void>;
    render(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=FlxLearningWebPart.d.ts.map