declare const styles: {
    mobilePreviewDeviceIcon: string;
    navBarItemRight: string;
};
export default styles;
//# sourceMappingURL=MobilePreviewDeviceTypeSelector.module.scss.d.ts.map