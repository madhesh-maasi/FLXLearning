declare const styles: {
    mobilePreviewContainer: string;
    mobilePreviewDeviceContainer: string;
};
export default styles;
//# sourceMappingURL=MobilePreview.module.scss.d.ts.map