(window["webpackJsonp_8217e442_8ed3_41fd_957d_b112e841286a_0_8_24"] = window["webpackJsonp_8217e442_8ed3_41fd_957d_b112e841286a_0_8_24"] || []).push([["sp-client-telemetry-aria-webjs"],{

/***/ "8Gis":
/*!*********************************!*\
  !*** ./lib/ariaWebJsWrapper.js ***!
  \*********************************/
/*! exports provided: ariaWebJsWrapper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ariaWebJsWrapper", function() { return ariaWebJsWrapper; });
/* harmony import */ var _ms_utilities_ariawebjs_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms/utilities-ariawebjs-wrapper */ "RWZ3");

// tslint:disable-next-line:no-any
var ariaWebJsWrapper = {
    EventProperties: _ms_utilities_ariawebjs_wrapper__WEBPACK_IMPORTED_MODULE_0__["AriaWebJsEventProperties"],
    Exception: _ms_utilities_ariawebjs_wrapper__WEBPACK_IMPORTED_MODULE_0__["AriaWebJsMockException"],
    Logger: _ms_utilities_ariawebjs_wrapper__WEBPACK_IMPORTED_MODULE_0__["AriaWebJsLogger"],
    LogManager: _ms_utilities_ariawebjs_wrapper__WEBPACK_IMPORTED_MODULE_0__["AriaWebJsLogManager"]
};


/***/ })

}]);
//# sourceMappingURL=chunk.sp-client-telemetry-aria-webjs_248b979973305f881e1b.js.map