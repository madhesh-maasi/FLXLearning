declare interface IFlxLearningWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'FlxLearningWebPartStrings' {
  const strings: IFlxLearningWebPartStrings;
  export = strings;
}
