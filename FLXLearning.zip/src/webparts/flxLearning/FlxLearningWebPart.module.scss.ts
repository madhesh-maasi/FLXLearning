/* tslint:disable */
require("./FlxLearningWebPart.module.css");
const styles = {
  flxLearning: 'flxLearning_c9590ade',
  container: 'container_c9590ade',
  row: 'row_c9590ade',
  column: 'column_c9590ade',
  'ms-Grid': 'ms-Grid_c9590ade',
  title: 'title_c9590ade',
  subTitle: 'subTitle_c9590ade',
  description: 'description_c9590ade',
  button: 'button_c9590ade',
  label: 'label_c9590ade'
};

export default styles;
/* tslint:enable */